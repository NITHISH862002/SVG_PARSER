#include <iostream>
// #include "path.cpp"

// #include "D:\C++\SVG_Parser\Home_SVG_Parser\Elements\Path.cpp"
#include "../Elements/Path.cpp"
class Group : public Shape
{
public:
    Group() : Shape("Group") { //std::cout << "group"; 
    }
};
