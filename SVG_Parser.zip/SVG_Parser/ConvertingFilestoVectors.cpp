#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include"Elements\Group.cpp"
#include "XMLParser/pugixml.cpp"

class ConvertingFilestoVectors
{
public:
    std::vector<std::string> strr;

    int convertingFilestoVectors(std::string s, Structure &str)
    {
        char *x = (char *)s.c_str();
        std::ifstream svgFile(x);
        std::string svgContent((std::istreambuf_iterator<char>(svgFile)), std::istreambuf_iterator<char>());

        // Parse the SVG content using PugiXML
        pugi::xml_document doc;
        pugi::xml_parse_result result = doc.load_string(svgContent.c_str());

        // Check for parsing errors
        if (result.status != pugi::xml_parse_status::status_ok)
        {
            std::cerr << "Failed to parse SVG file. Error description: " << result.description() << std::endl;
            // std::cout << "false";
            return -1;
        }

        
        pugi::xml_node root = doc.child("svg");

        
        for (pugi::xml_node node = root.first_child(); node; node = node.next_sibling())
        {
            // Serialize the individual XML element into a string
            std::stringstream tagStream;
            node.print(tagStream);

            // Get the tag as a string
            std::string tag = tagStream.str();
            
            if (node.name() == std::string("g"))
            {
                

                strr.push_back(tagStream.str());
                str.shapes.push_back(Group());
                str.Group.push_back(tagStream.str());
            }
            else if (node.name() == std::string("rect"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Rectangle());
                str.Reactangle.push_back(tagStream.str());
            }
            else if (node.name() == std::string("circle"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Circle());
                str.Circle.push_back(tagStream.str());
            }
            else if (node.name() == std::string("ellipse"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Ellipse());
                str.Ellipse.push_back(tagStream.str());
            }
            else if (node.name() == std::string("polyline"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Polyline());
                str.Polyline.push_back(tagStream.str());
            }
            else if (node.name() == std::string("line"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Line());
                str.Line.push_back(tagStream.str());
            }
            else if (node.name() == std::string("polygon"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Polygon());
                str.Polygon.push_back(tagStream.str());
            }
            else if (node.name() == std::string("path"))
            {
                strr.push_back(tagStream.str());
                str.shapes.push_back(Path());
                str.Path.push_back(tagStream.str());
            }
            else{
                strr.push_back(tagStream.str());
                str.shapes.push_back(Others());
                str.others.push_back(tagStream.str());
            }
        
        }
        return 0;
       
    }
};
